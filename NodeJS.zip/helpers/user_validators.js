const Joi = require('joi');

const registerSchema = Joi.object({
    name: Joi.string().min(2).max(255).required(),
    email: Joi.string().min(5).max(255).required().email(),
    password: Joi.string().min(6).max(1024).required(),
    // role: Joi.string().valid('USER', 'ADMIN').default('USER')
});

const loginSchema = Joi.object({
    email: Joi.string().min(5).max(255).required().email(),
    password: Joi.string().min(6).max(1024).required()
});

module.exports = {
    registerSchema,
    loginSchema
};
